import "./styles.css";
import { useState } from 'react';
export default function App() {

  const [cards, setCards] = useState([
    { id: 1, title: "Card 1", description: "Description for Card 1" },
    { id: 2, title: "Card 2", description: "Description for Card 2" },
    { id: 3, title: "Card 3", description: "Description for Card 3" },
    { id: 4, title: "Card 4", description: "Description for Card 4" },
    { id: 5, title: "Card 5", description: "Description for Card 5" },
  ]);
  


  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
      <h2>Start editing to see some magic happen!</h2>

      <div className="grid grid-cols-03 gap-4 mt-4">
        {cards.map((card, index) => (
          <div key={card.id}>
            <h3>{card.title}</h3>
            <p>{card.description}</p>
            <select
              value={index}
              onChange={(e) => {
                const currentIndex = index;
                const newPosition = parseInt(e.target.value);
                if (currentIndex !== newPosition) {
                  const updatedCards = Array.from(cards);
                  updatedCards.splice(newPosition, 0, updatedCards.splice(currentIndex, 1)[0]);
                  setCards(updatedCards);
                }
              }}
            >
              {cards.map((card, index) => (
                <option key={card.id} value={index}>
                  {index + 1}
                </option>
              ))}
            </select>
          </div>
        ))}

        </div>


            </div>
          );
        }
